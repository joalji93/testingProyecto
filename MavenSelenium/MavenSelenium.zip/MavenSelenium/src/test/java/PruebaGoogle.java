import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertEquals;

public class PruebaGoogle  {
    static WebDriver driver;
public static void main(String[]args){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\jonatan\\Desktop\\MavenSelenium\\src\\test\\sources\\chromedriver\\chromedriver.exe");
        String baseURL = "https://jonatanproyecto.herokuapp.com/";

        driver = new ChromeDriver();

        driver.manage().window().maximize();

        driver.get(baseURL);


    try{
        driver.findElement(By.linkText("Graficas")).click();
        Thread.sleep(2000);
        driver.findElement(By.linkText("Gráfica 1")).click();
        Thread.sleep(2000);

        WebElement searchBox = driver.findElement(By.xpath("//a[@href='/index']"));
        searchBox.click();
        Thread.sleep(1000);

        WebElement campoNombre = driver.findElement(By.xpath("//input[@name='nombre']"));
        campoNombre.sendKeys("Real Betis Balompie");
        Thread.sleep(1000);

        WebElement campoCapacidad = driver.findElement(By.xpath("//input[@name='capacidad']"));
        campoCapacidad.sendKeys("1000");
        Thread.sleep(1000);

        WebElement campoFecha = driver.findElement(By.xpath("//input[@name='fechaIna']"));
        campoFecha.sendKeys("04021993");
        Thread.sleep(1000);

        WebElement campoEspecialidad = driver.findElement(By.xpath("//input[@name='especialidad']"));
        campoEspecialidad.sendKeys("maternidad");
        Thread.sleep(1000);

        WebElement campoDirector = driver.findElement(By.xpath("//input[@name='director']"));
        campoDirector.sendKeys("Jonatan Alvarez");
        Thread.sleep(3000);

        WebElement campoBoton = driver.findElement(By.xpath("//button[@class='btn btn-primary col-md-12']"));
        campoBoton.click();
        Thread.sleep(1000);

        driver.findElement(By.xpath("//a[@href='/tabla']")).click();
        Thread.sleep(1000);

        WebElement miHospital = driver.findElement(By.xpath("//tr/td[contains(text(), 'Real Betis Balompie')]"));
        miHospital.click();
        Thread.sleep(4000);

        WebElement campoBorrar = driver.findElement(By.xpath("//tr/td"));
        campoBorrar.click();
        Thread.sleep(1000);

            System.out.println("Test completado correctamente");
        } catch (Exception e) {
            System.out.println("Hubo un fallo inesperado");
        }finally{
            driver.close();
        }
    
}
}
